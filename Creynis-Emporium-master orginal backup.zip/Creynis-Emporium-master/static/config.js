// ***********************************************************************************
// ID of the Google spreadsheet
// ***********************************************************************************
// Make sure your spreadsheet is published (File > Publish to the web…)
var spreadsheetId = "1YBSb3r7qfCJvaWCXVRHBDA1iDMBzGXQUZC4CklHHEqs";

// ***********************************************************************************
// Your FC and IGN
// ***********************************************************************************
var friendCode = "2595-5634-2087";
var inGameName = "Johnny";

// ***********************************************************************************
// URL of your Reddit/Twitter account
// ***********************************************************************************
var contactUrl = "Discord: TheJigmeister#4272";

// ***********************************************************************************
// URL of your PGL trainer icon (optional)
// ***********************************************************************************
// Download it from the Pokémon Global Link and re-upload to an image-sharing website
var trainerIconUrl = "https://n-3ds1-pgl-trainericon.pokemon-gl.com/d315dac0-ae8f-11e6-a3fc-06af8a77a80d.png"; 
